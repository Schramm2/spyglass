# Spyglass review

Status: passed
Run: ci-passed-41867158951-1
Source commit: df214f3584234feba03d8cf528ab9a4a36ad101c
Source fingerprint: 83e22ea5849b586b7d71ff843b5ba8ae97c2d10e51e2474aee1218d633bb8dc4
Current fingerprint: 83e22ea5849b586b7d71ff843b5ba8ae97c2d10e51e2474aee1218d633bb8dc4

This summary records this run only. Workflow provenance identifies CI proof; local proof is separate.
Open the offline HTML report for attempts and artifacts. A passed claim does not prove behavior outside its plan.

## Claims
- fixture-ready: passed — The fixture check detects the fault and passes after restoration&#46;
  Expected: The unchanged fixture-ready assertion passes after the fault is removed&#46;
  Observed: The unchanged fixture-ready assertion passed after the fault marker was removed&#46;
  Steps: fc4f3c30-b93
  Artifacts: fc4f3c30-b93-1-verify-output&#46;txt

## Controls
- detect-fault: passed — The same assertion fails with the fault marker and passes without it&#46;
  Assertion: fixture-ready
  Validated intended failure: run ci-passed-41867158951-1, step 801c30cb-62e — The fixture-ready assertion was false with the marker present&#46;
  Validated restored pass: step fc4f3c30-b93 — The same assertion was true after removal&#46;
  Recorded attempt (not validated control proof): failed, step 801c30cb-62e, status failed
  Recorded attempt (not validated control proof): restored, step fc4f3c30-b93, status passed

## Gates
- verify: passed — run ci-passed-41867158951-1, steps fc4f3c30-b93

## Cleanup
- Run state: stopped
- Spyglass resources cleaned: true
- External owner cleaned: not required

## Limits
- Scripted public fixture proof only; no agent speed, browser, database or human-usability claim&#46;
- The ignored marker is an environment control, not a product-source mutation&#46;

## Findings
- None.
