# Spyglass review

Status: incomplete
Run: ci-incomplete-41861617920-1
Source commit: f045ade58d415b0eef10a78109c93ba603dea868
Source fingerprint: fa42b4258cfa5baea220b03016e104371a9f8145ef937b2c02f40f59f57af59b
Current fingerprint: fa42b4258cfa5baea220b03016e104371a9f8145ef937b2c02f40f59f57af59b

This summary records this run only. Workflow provenance identifies CI proof; local proof is separate.
Open the offline HTML report for attempts and artifacts. A passed claim does not prove behavior outside its plan.

## Claims
- fixture-ready: not run — The fixture check detects the fault and passes after restoration&#46;
  Expected: The unchanged fixture-ready assertion passes after the fault is removed&#46;
  Observed: 
  Steps: none
  Artifacts: none

## Controls
- detect-fault: not run — The same assertion fails with the fault marker and passes without it&#46;
  Assertion: fixture-ready
  Intended failure: run ci-incomplete-41861617920-1, step not recorded — not recorded
  Restored pass: step not recorded — not recorded
  Recorded attempt (not validated control proof): failed, step 0c129f11-e0b, status failed

## Gates
- verify: not run — run ci-incomplete-41861617920-1, steps none

## Cleanup
- Run state: stopped
- Spyglass resources cleaned: true
- External owner cleaned: not required

## Limits
- Scripted public fixture proof only; no agent speed, browser, database or human-usability claim&#46;
- The ignored marker is an environment control, not a product-source mutation&#46;

## Findings
- RESULT&#95;MISSING: No result has been recorded for this run&#46; Submit it with spyglass result --file PATH&#46;
- CONTROL&#95;INCOMPLETE: Required negative control detect-fault has no failed-then-restored result&#46;
