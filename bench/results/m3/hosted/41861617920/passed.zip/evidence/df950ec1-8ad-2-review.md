# Spyglass review

Status: passed
Run: ci-passed-41861617920-1
Source commit: f045ade58d415b0eef10a78109c93ba603dea868
Source fingerprint: fa42b4258cfa5baea220b03016e104371a9f8145ef937b2c02f40f59f57af59b
Current fingerprint: fa42b4258cfa5baea220b03016e104371a9f8145ef937b2c02f40f59f57af59b

This summary records this run only. Workflow provenance identifies CI proof; local proof is separate.
Open the offline HTML report for attempts and artifacts. A passed claim does not prove behavior outside its plan.

## Claims
- fixture-ready: passed — The fixture check detects the fault and passes after restoration&#46;
  Expected: The unchanged fixture-ready assertion passes after the fault is removed&#46;
  Observed: The unchanged fixture-ready assertion passed after the fault marker was removed&#46;
  Steps: 863f1208-c63
  Artifacts: 863f1208-c63-1-verify-output&#46;txt

## Controls
- detect-fault: passed — The same assertion fails with the fault marker and passes without it&#46;
  Assertion: fixture-ready
  Intended failure: run ci-passed-41861617920-1, step c82927aa-cc5 — The fixture-ready assertion was false with the marker present&#46;
  Restored pass: step 863f1208-c63 — The same assertion was true after removal&#46;
  Recorded attempt (not validated control proof): failed, step c82927aa-cc5, status failed
  Recorded attempt (not validated control proof): restored, step 863f1208-c63, status passed

## Gates
- verify: passed — run ci-passed-41861617920-1, steps 863f1208-c63

## Cleanup
- Run state: stopped
- Spyglass resources cleaned: true
- External owner cleaned: not required

## Limits
- Scripted public fixture proof only; no agent speed, browser, database or human-usability claim&#46;
- The ignored marker is an environment control, not a product-source mutation&#46;

## Findings
- None.
