# Spyglass review

Status: passed
Run: ci-passed-41858307522-1
Source commit: 3fb71f3d920c07ab453698663be4d85f36d205ec
Source fingerprint: 7348cdb49bd41baf4f2baf2b9c312facc8b04085b8c6f4aafd7b86f77753aed4
Current fingerprint: 7348cdb49bd41baf4f2baf2b9c312facc8b04085b8c6f4aafd7b86f77753aed4

This summary records this run only. Workflow provenance identifies CI proof; local proof is separate.
Open the offline HTML report for attempts and artifacts. A passed claim does not prove behavior outside its plan.

## Claims
- fixture-ready: passed — The fixture check detects the fault and passes after restoration&#46;
  Expected: The unchanged fixture-ready assertion passes after the fault is removed&#46;
  Observed: The unchanged fixture-ready assertion passed after the fault marker was removed&#46;
  Steps: e40472b9-9a8
  Artifacts: e40472b9-9a8-1-verify-output&#46;txt

## Controls
- detect-fault: passed — The same assertion fails with the fault marker and passes without it&#46;
  Assertion: fixture-ready
  Intended failure: run ci-passed-41858307522-1, step a12f1e6c-e18 — The fixture-ready assertion was false with the marker present&#46;
  Restored pass: step e40472b9-9a8 — The same assertion was true after removal&#46;
  Recorded attempt (not validated control proof): failed, step a12f1e6c-e18, status failed
  Recorded attempt (not validated control proof): restored, step e40472b9-9a8, status passed

## Gates
- verify: passed — run ci-passed-41858307522-1, steps e40472b9-9a8

## Cleanup
- Run state: stopped
- Spyglass resources cleaned: true
- External owner cleaned: not required

## Limits
- Scripted public fixture proof only; no agent speed, browser, database or human-usability claim&#46;
- The ignored marker is an environment control, not a product-source mutation&#46;

## Findings
- None.
