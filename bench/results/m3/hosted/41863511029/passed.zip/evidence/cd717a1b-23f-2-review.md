# Spyglass review

Status: passed
Run: ci-passed-41863511029-1
Source commit: 2e7a3df7a2a227ccc08f2a84ca962f152f439364
Source fingerprint: f149436d3d53e0872ccb4f674d9c0fd44ec337e90a9ecdf0268a3f8d1ba85d0b
Current fingerprint: f149436d3d53e0872ccb4f674d9c0fd44ec337e90a9ecdf0268a3f8d1ba85d0b

This summary records this run only. Workflow provenance identifies CI proof; local proof is separate.
Open the offline HTML report for attempts and artifacts. A passed claim does not prove behavior outside its plan.

## Claims
- fixture-ready: passed — The fixture check detects the fault and passes after restoration&#46;
  Expected: The unchanged fixture-ready assertion passes after the fault is removed&#46;
  Observed: The unchanged fixture-ready assertion passed after the fault marker was removed&#46;
  Steps: 20a9547a-798
  Artifacts: 20a9547a-798-1-verify-output&#46;txt

## Controls
- detect-fault: passed — The same assertion fails with the fault marker and passes without it&#46;
  Assertion: fixture-ready
  Validated intended failure: run ci-passed-41863511029-1, step 61dd8a06-151 — The fixture-ready assertion was false with the marker present&#46;
  Validated restored pass: step 20a9547a-798 — The same assertion was true after removal&#46;
  Recorded attempt (not validated control proof): failed, step 61dd8a06-151, status failed
  Recorded attempt (not validated control proof): restored, step 20a9547a-798, status passed

## Gates
- verify: passed — run ci-passed-41863511029-1, steps 20a9547a-798

## Cleanup
- Run state: stopped
- Spyglass resources cleaned: true
- External owner cleaned: not required

## Limits
- Scripted public fixture proof only; no agent speed, browser, database or human-usability claim&#46;
- The ignored marker is an environment control, not a product-source mutation&#46;

## Findings
- None.
